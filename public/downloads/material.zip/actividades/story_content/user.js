function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6qDlyo0ifVI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

